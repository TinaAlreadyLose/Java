package www.ambow.test;
import www.ambow.pojo.Teacher;
import www.ambow.dao.TeacherDao;
public class testTeacherDAO {
		public static void main(String[] args){
			TeacherDao td=new TeacherDao();
			Teacher teacher =new Teacher("04","dan");
			int i=td.add(teacher);
			if(i>0){
				System.out.println("success add");
			}else{
				System.out.println("faild  add");
			}
		}
}
