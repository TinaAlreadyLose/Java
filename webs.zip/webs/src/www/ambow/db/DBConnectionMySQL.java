package www.ambow.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class DBConnectionMySQL {
	private static final String DRIVER = "com.mysql.jdbc.Driver";//���ݿ�����
	private static final String URL = "jdbc:mysql://localhost:3306/test";//ͨ��Э��:���ݿ�����:���ݿ�ĵ�ַ:ʹ���ĸ��˿�/���ݿ�����
	private static final String USERNAME = "root";//�˺�
	private static final String PASSWORD = "";//����
	
	public static Connection getCon(){
		Connection con = null;
		try {
			Class.forName(DRIVER);
			con = DriverManager.getConnection(URL,USERNAME,PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public static void main(String[] args) {
		getCon();
	}
	public static void query(){
		Connection con = getCon();
		String sql = "select * from t_user";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString(1)+":"+rs.getString(2));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
}
