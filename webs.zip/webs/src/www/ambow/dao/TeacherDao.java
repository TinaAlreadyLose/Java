package www.ambow.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import www.ambow.db.DBConnectionMySQL;
import www.ambow.pojo.Teacher;

public class TeacherDao {
	DBConnectionMySQL dfm=new DBConnectionMySQL();
	public int add(Teacher teacher){
		int i=0;
		Connection con = dfm.getCon();
		String sql = "insert into teacher values(?,?)";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, teacher.getId());
			pstmt.setString(2, teacher.getName());
			i=pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return i;
	}
	public int update(Teacher teacher){
		int i=0;
		return i;
	}
	public int delete(Teacher teacher){
		int i=0;
		return i;
	}
}
